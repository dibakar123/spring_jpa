package com.example.demojpa2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demojpa2.entity.Persons;
import com.example.demojpa2.service.PersonService;

@SpringBootApplication
public class Demojpa2Application {

	
	
	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Demojpa2Application.class, args);
		
		PersonService service = ctx.getBean(PersonService.class);
	
	// to insert data
	/*Persons p = new Persons();
	p.setEmail("dd@aa.com");
	p.setName("Asim");
	p.setAddress("Pune");
	p.setPassword("123");
	p.setState("pune");
	service.addPerson(p);*/
		
   /* //search by address
		List<Persons> plist = service.findAllByAddress("kolkata");
		for(Persons p:plist) {
			System.out.println(p);
		}*/
		
	/*	//search by address
				List<Persons> plist = service.findAllByAddress1("kolkata");
				for(Persons p:plist) {
					System.out.println(p);
				}*/
	
	/*	//search by address using native query
		List<Persons> plist = service.findAllByAddress2("kolkata");
		for(Persons p:plist) {
			System.out.println(p);
		}*/

	/*	//search by address using native query
		List<Object[]> plist = service.findAllByAddress3("kolkata");
		for(Object[] p:plist) {
			System.out.println(p[0]+"  "+p[1]);
		}*/
		
/*		//search by top 3
		List<Persons> plist = service.findTop3ByAddressOrderByNameDesc("kolkata");
		for(Persons p:plist) {
			System.out.println(p);
		}*/
		
		/*//search by address using native query
		List<Persons> plist = service.fetchByAddress("kolkata");
		for(Persons p:plist) {
			System.out.println(p);
		}*/
		
		//search by address using native query
				List<Persons> plist = service.fetchByName("Asim");
				for(Persons p:plist) {
					System.out.println(p);
				}
		
   /* //show by name desc
		List<Persons> plist = service.findByOrderByNameDesc();
		for(Persons p:plist) {
			System.out.println(p);
		}*/
				
	}

}
