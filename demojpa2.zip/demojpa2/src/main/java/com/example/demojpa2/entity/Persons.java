package com.example.demojpa2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Person123")
@NamedQueries({
@NamedQuery(name = "Persons.fetchByAddress",query = "SELECT p FROM Persons p WHERE p.address =:address"),
@NamedQuery(name = "Persons.fetchByName",query = "SELECT p FROM Persons p WHERE p.name =:name")
})
public class Persons {
	@Column(name="name", length = 50)
    private String name;
    @Id
    @Column(length = 50)
    private String email;

    @Column(length = 20)
    private String address;
    
    @Column(length = 10)
    private String password;
    
    @Column(length = 10)
    private String state;
    @Column(length = 10)
    private String city;
	
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Persons [name=" + name + ", email=" + email + ", address=" + address + ", password=" + password
				+ ", state=" + state + ", city=" + city + "]";
	}
    
    
}
