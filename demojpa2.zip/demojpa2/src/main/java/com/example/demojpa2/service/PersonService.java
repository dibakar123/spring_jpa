package com.example.demojpa2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demojpa2.entity.Persons;
import com.example.demojpa2.repository.PersonRepository;

@Service

public class PersonService {

	@Autowired
	PersonRepository repo;
	
	
	@Transactional
	public void addPerson(Persons p) {
		 repo.save(p);
	}
	
	@Transactional
	public List<Persons> findAllByAddress(String address){
		List<Persons> plist = repo.findAllByAddress(address);
		return plist;
	}
	
	@Transactional
	public List<Persons> findTop3ByAddressOrderByNameDesc(String address){
		List<Persons> plist = repo.findTop3ByAddressOrderByNameDesc(address);
		return plist;
	}
	
	@Transactional
	public List<Persons> findAllByAddress2(@Param("address") String address){
		List<Persons> plist = repo.findAllByAddress2(address);
		return plist;
	}
	
	@Transactional
	public List<Object[]> findAllByAddress3(@Param("address") String address){
		List<Object[]> plist = repo.findAllByAddress3(address);
		return plist;
	}
	
	@Transactional
	public List<Persons> findAllByAddress1(@Param("address") String address){
		List<Persons> plist = repo.findAllByAddress1(address);
		return plist;
	}
	
	
	@Transactional
	public List<Persons> findByOrderByNameDesc(){
		List<Persons> plist = repo.findByOrderByNameDesc();
		return plist;
	}
	
	@Transactional
	public List<Persons> fetchByAddress(@Param("address") String address){
		List<Persons> plist = repo.fetchByAddress(address);
		return plist;
	}
	
	@Transactional
	public List<Persons> fetchByName(@Param("address") String name){
		List<Persons> plist = repo.fetchByName(name);
		return plist;
	}
}
