package com.example.demojpa2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.demojpa2.entity.Persons;

public interface PersonRepository extends CrudRepository<Persons, String> {

	
	public List<Persons> findByOrderByNameDesc();
	public List<Persons> findAllByAddress(String address);
	public List<Persons> findTop3ByAddressOrderByNameDesc(String address);
	
	
	
	@Query(value="select p from Persons p where p.address = :address")
	public List<Persons> findAllByAddress1(@Param("address") String address);
	
	@Query(value="select * from person123 where address = :address order by name desc" , nativeQuery=true)
	public List<Persons> findAllByAddress2(@Param("address") String address);
	
	@Query(value="select name, state from person123 where address = :address order by name desc" , nativeQuery=true)
	public List<Object[]> findAllByAddress3(@Param("address") String address);
	
	
	public List<Persons> fetchByAddress(@Param("address") String address);
	public List<Persons> fetchByName(@Param("name") String name);
}
